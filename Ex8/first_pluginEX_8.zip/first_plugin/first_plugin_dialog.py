import os
from qgis.PyQt import uic
from qgis.PyQt import QtWidgets

# Load the .ui file dynamically
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'first_plugin_dialog_base.ui'))


class myfirstpluginDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(myfirstpluginDialog, self).__init__(parent)
        self.setupUi(self)

        # Connect buttons
        self.pushButton.clicked.connect(self.handle_get_data)
        self.pushButton_2.clicked.connect(self.handle_export_data)

    def handle_get_data(self):
        print("Get Data button clicked")

    def handle_export_data(self):
        print("Export Data button clicked")
